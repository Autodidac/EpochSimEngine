@echo off
cd /d "%~dp0"
SandHybrid.exe
